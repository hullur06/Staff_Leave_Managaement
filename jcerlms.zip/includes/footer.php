<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> | JCER Leave Management System| Developed By <a href="#">ritesh.exe</a></p>
        </div>
</footer>